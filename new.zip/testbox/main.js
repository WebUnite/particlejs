window.onload = init;
var Ship = null;
var right = null;
var left = null;
var up = null;
var down = null;

function ship(){
    this.obj = null;
    this.velocity = 0;
    this.X = NaN;
    this.Y = NaN;
}

ship.prototype.gen = function(x,y){
    this.obj = document.createElement("div");
    this.obj.style.zIndex = "-2";
    this.obj.style.position = 'absolute';
    this.X = x;
    this.Y = y;
    this.obj.style.top = y+"px";
    this.obj.style.left = x+"px";
    this.obj.style.backgroundImage = 'url("../img/ship.png")';
    this.obj.style.backgroundSize = 'contain';
    this.obj.style.width= '50px';
    this.obj.style.height = '50px';
    document.body.appendChild(this.obj);
}

ship.prototype.move = function(){
    var x = this.X;
    var y = this.Y;
    if(up == true){
        y -= 8;
    } 
    if(down == true){
        y += 8;
    }
    if(left == true){
        x -= 8;
    }
    if (right == true){
        x += 8;
    };
    this.obj.style.top = y+"px";
    this.obj.style.left = x+"px";
    this.X = x;
    this.Y = y;
}

function init(){
    document.body.style.position = 'absolute';
    var updateInterval = setInterval(update, 50);
    Ship = new ship();
    Ship.gen(400,400);

    document.onkeydown = function(e){
        if (e.keyCode == 87) {
            up = true;
        }
        if(e.keyCode == 65){
            left = true;
        }
        if (e.keyCode == 68 && right == false) {
            right = true;
        }
        if(e.keyCode == 83){
            down = true;
        };
    };

    document.onkeyup = function(e){
        if (e.keyCode == 87) {
            up = false;
        }
        if(e.keyCode == 65){
            left = false;
        } 
        if (e.keyCode == 68) {
            right = false;
        } 
        if(e.keyCode == 83){
            down = false;
        };
    };
}

function update(){
    Ship.move();
}